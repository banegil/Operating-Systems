#include "archi.h"

int main(void)
{
	printf("Hola ...%d\n", VAR);
}

